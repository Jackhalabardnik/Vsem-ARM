#include "PIO_library.h"    // Dołączam moją bibliotekę
#include <ctl_api.h>

#define BL PIOB_PER_P20
#define SW1 PIOB_PER_P24
#define SW2 PIOB_PER_P25

//Zad 2: uruchomi� przerwania od zmiany stanu PB24 i PB25 (SW1 i SW2), wci�ni�cie SW1 za�wieca, wci�ni�cie SW2 gasi pod�wietlenie

void button_przerw(){
int check = PIOB_ISR;
if((check & SW2)!=0)
PIOB_CODR = BL;
if((check & SW1)!=0)
PIOB_SODR = BL;
}

int main(void){
PMC_PCER = PMC_PCER_PIOB ; // za��czenie zegara PIOB
PIOB_PER = BL; // Pin Enable Register - za��czenie pinu P20
PIOB_OER = BL; // Output Enable Register - ustawienie Pinu20 w tryb wyj�ciowy OSR - sprawdzanie stanu ODR - disable
PIOB_IER = 1<<24 | 1<<25;

//konfiguracja przerwania od TC0
ctl_global_interrupts_disable(); //globalne wy��czenie przerwa�
ctl_set_isr(3,1,CTL_ISR_TRIGGER_FIXED,button_przerw,0); // konfiguracja przerwania od timera, powi�zanie procedury obs�ugi przerwania ze �r�d�em - wstawi� Peripheral Identifier TC0
ctl_unmask_isr(3); // zezwolenie na przerwania od timera (wy��czenie procedury obs�ugi przerwania, czyli programowe nie sprz�towe) - wstawi� Peripheral Identifier TC0
ctl_global_interrupts_enable(); //zezwolenie na globalne przerwania
for(;;) {}
}
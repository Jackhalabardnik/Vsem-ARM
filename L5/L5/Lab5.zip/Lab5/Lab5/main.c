#include "lcd.h"					// Dołączam moją bibliotekę
#include <avr/interrupt.h>			// biblioteka do przerwań
#include <stdlib.h>					// bliblioteka do opóźnień

volatile char number  = 0;		// zapamiętuję ostatnio wciśnięty klawisz

void show_number(char num)		// funkcja wyświetlająca numer
{
	if(num != number)			// jeżeli obecny kod klawisza jest inny od poprzedniego
	{
		LCD_CLEAR();				// czyszczę wyświetlacz
		char buffer[3];				// tworzę bufor dla funkcji itoa 
		itoa(num, buffer, 10);		// przetwarzam kod klawisza na ciąg znaków
		buffer[2]= '\0';			// dodaję pusty znak na koniec żeby utworzyć poprawny ciąg znaków w C
		LCD_WRITE(buffer);			// wyświetlam znak
	}
	number = num;
}

int debinary(int x)			// wyodrębniam numer bitu na podstawie wartości dziesiętnej połowy bajta
{
	if(x == 8) {			// 4 bit
		return 4;
	}
	if(x == 4) {			// 3 bit
		return 3;
	}
	return x;				// 2 lub 1 bit
}

ISR (TIMER0_COMP_vect) {        				// Przerwanie TIMER0
	
	if((PIND & 0x0F) != 0x0F)						// Wykrywam że na jedenym z wierszy jest logiczne 0
	{
		char row = debinary(~PIND & 0x0F);					// Zapamiętuję która to wiersza
		char backup_DDRD = DDRD;
		char backup_PORTD = PORTD;

		DDRD ^= 0xFF;							// Zamieniam linie wierszy
		PORTD ^= 0xFF;							// Zamieniam podciągnięcia linii wierszy

		char column = debinary((PIND & 0xF0) >> 4);				// Odczytuję stan linii kolumn
		show_number((row-1)*4 + column);					// Wyświetlam kod znaku na wyświetlaczu
		DDRD = backup_DDRD;							// Przywracam zapisane stany linii
		PORTD = backup_PORTD;
	}
}

int main(void)
{
	DDRD = 0xF0;                // Ustawiam starsze bity linii D jako wyjście

	PORTD |= 0x0F;                // podciągam młodsze bity PORTD pod zasilanie

	OCR0 = 195;                    // ustawienie momentu przerwania na 195 (0,05s)

	TIMSK |= 0x02;                 // włączenie przerwania TIMER0

	TCCR0 |= 0b01000101;            // włączam tryb CTC i ustawiam prescaler na 1/1024

	sei();                        // włączam obsługę przerwań
	
    LCD_INIT();						// Inicjalizuję wyświetlacz
    while (1) 
    {
		asm volatile("nop");		// Wykonuję niekończoną pętlę przez resztę czasu
    }
}

